<?php

class Anagrafica {

    //-------------------- PROPERTIES ----------------------------------- //
		
		private $id;
		private $indirizzo;
		private $cognome;
		private $nome;
		private $sesso;
		private $nazionalita;
		private $cf;
		private $luogo_nascita;
		private $data_nascita;
		private $provincia_nascita;
		private $ragione_sociale;
		private $piva;
		private $num; 
		private $cap;
		private $stato;
		private $cel;

    //--------------------- METHODS ----------------------------------- //
	
	public function insertAnagrafica($arr){
		$sqlFields = array_keys($arr);
		$sqlFieldsValues = array_values($arr);
		$sqlFields = implode(", ", $sqlFields);
		$sqlFieldsValues = implode("', '", $sqlFieldsValues);
		$strSql = "insert into clienti (".$sqlFields.") values ('".$sqlFieldsValues."')";
		return $strSql;
		
	}
	
	public function updateAnagrafica($arr,$id){
		$colonne = "";
		$sqlFields = array_keys($arr);
		$sqlFieldsValues = array_values($arr);
		//$sqlFields = implode(", ", $sqlFields);
		//$sqlFieldsValues = implode("', '", $sqlFieldsValues);
		$i=0;
		while($i<count($sqlFields)){
			$colonne .= "".$sqlFields[$i]."='".$sqlFieldsValues[$i]."',";
			$i++;
		}
		$colonne = substr($colonne, 0, strlen($colonne)-1);
		echo $colonne;
		$strSql = "update clienti set  ".$colonne." WHERE id='".$id."' ";
		echo $strSql;
		return $strSql;
	}
	
	public function deleteAnagrafica($id){
		$strSql = "
			delete from clienti
 			where
				id = '" . $id "'
			";
	}
	
	
	
	
	
	//--------------------- GETTER AND SETTER ------------------------- //
    public function getCognome() {
        return $this->cognome;
    }

    public function setCognome($cognome) {
        $this->cognome = $cognome;
    }

    public function getIndirizzo() {
        if (isset($this->indirizzo))
            return $this->indirizzo;
    }


    public function setIndirizzo($indirizzo) {
        $this->indirizzo = $indirizzo;
    }


    public function getNome() {
        if (isset($this->nome))
            return $this->nome;
    }


    public function setNome($nome) {
        $this->nome = $nome;
    }


    public function getSesso() {
        if (isset($this->sesso))
            return $this->sesso;
    }


    public function setSesso($sesso) {
        $this->sesso = $sesso;
    }


    public function getNazionalita() {
        if (isset($this->nazionalita))
            return $this->nazionalita;
    }


    public function setNazionalita($nazionalita) {
        $this->nazionalita = $nazionalita;
    }


    public function getCf() {
        if (isset($this->cf))
            return $this->cf;
    }


    public function setCf($cf) {
        $this->cf = $cf;
    }



    public function getLuogoNascita(){
		if (isset($this->luogo_nascita))
			return $this->luogo_nascita;
    }


    public function setLuogoNascita($luogo_nascita){
        $this->luogo_nascita = $luogo_nascita;
    }


    public function getDataNascita(){
		if (isset($this->data_nascita))
			return $this->data_nascita;
    }


    public function setDataNascita($data_nascita){
        $this->data_nascita = $data_nascita;
    }


    public function getProvinciaNascita(){
		if (isset($this->provincia_nascita))
			return $this->provincia_nascita;
    }


    public function setProvinciaNascita($provincia_nascita){
        $this->provincia_nascita = $provincia_nascita;
    }


    public function getRagioneSociale(){
		if (isset($this->ragione_sociale))
			return $this->ragione_sociale;
    }


    public function setRagioneSociale($ragione_sociale){
        $this->ragione_sociale = $ragione_sociale;
    }


    public function getPiva(){
		if (isset($this->piva))
			return $this->piva;
    }


    public function setPiva($piva){
        $this->piva = $piva;
    }


    public function getNum(){
		if (isset($this->num))
			return $this->num;
    }


    public function setNum($num){
        $this->num = $num;
    }

    public function getCap(){
		if (isset($this->cap))
			return $this->cap;
    }


    public function setCap($cap){
        $this->cap = $cap;
    }


    public function getStato(){
		if (isset($this->stato))
			return $this->stato;
    }


    public function setStato($stato){
        $this->stato = $stato;
    }


    public function getCel(){
		if (isset($this->cel))
			return $this->cel;
    }


    public function setCel($cel){
        $this->cel = $cel;
    }
	
	
}
?>
