<?php

function connect($db){
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db_name = $db;
	//instaura la connessione
	$conn = new mysqli($servername, $username, $password, $db_name);

	//errore di connessione
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	//connesso 
	return $conn;
}


?>