<?php

include ("funzioni.php");
require_once("classe.php");


$conn = connect("anagrafica");


print_r($_POST);
$a = new Anagrafica();


$a ->setIndirizzo($_POST["indirizzo"]);
$a ->setCognome($_POST["cognome"]);
$a ->setDataNascita($_POST["data_nascita"]);

$insertSql = $a ->insertAnagrafica($_POST);

$q = $conn->query($insertSql);


//$s = $a->updateAnagrafica($_POST,1);
//$x = $conn->query($s);

$conn->close();


?>