<?php

#richiedo la classe
require_once("classe.php");


#carico l'xml
$xml = simplexml_load_file("base.xml");


#converto l'oggetto in array
$array = xml2array($xml);



$html = "
<html>
<head>
<title>Form</title>
<link href='style.css' rel='stylesheet'>
</head>
<body>
<div class='login-page'>
  <div class='form'>
<form action='form.php' method='post'>";


foreach($array as $chiave=>$valore){
	foreach($valore as $chiave=>$valore){
		//creo il form 
		if($valore["visibile"]){
			switch($valore["tipo"]){
				case "text":
					$html.= $valore["label"]."<br><input type='text' name='".$valore['name']."' placeholder='".$valore['placeholder']."'
						value='".$valore['value']."'>";
				break;
				
				case "checkbox":
					$html.= $valore["label"]."<br><input type='checkbox' name='".$valore['name']."' value='".$valore['value']."'>";
				break;
				
				case "data":
					$html.= $valore["label"]."<br><input type='date' name='".$valore['name']."' placeholder='".$valore['placeholder']."' 
						value='".$valore['value']."'>";
				break;
				
			}
		}

	}
}


//chiudo il form
$html .= "
<input type='submit'>
</form>
</div>
</div>
</body>
</html>";
echo $html;

/*
$i=0;
$j=0;
foreach ($xml as $key ){
	foreach($key as $chiave=>$valore){
		#echo $i. " INDICE";
		switch($chiave){
			case 'name':
			#ricavo i valori dei campi
			$db[$i] = strval($valore);
			break;

			case 'label':
			$label[$i] = strval($valore);
			break;

			case 'placeholder':
			$holder[$i] = strval($valore);
			break;

			case 'value':
			$value[$i] = strval($valore);
			break;

			case 'tipo':
			$tipo[$i] = strval($valore);
			break;

			case 'fisso':
			$fisso[$i] = strval($valore);
			break;

			case 'visibile':
			$visibile[$i] = strval($valore);
			break;
		}
		$j++;
		if($j==7){
			$i++;
			$j=0;
		}

	}//end foreach
}//end foreach
*/
/*
print_r($db);
print_r($label);
print_r($holder);
print_r($value);
print_r($tipo);
print_r($fisso);
print_r($visibile);
*/



/*
#ora creo l'oggetto anagrafica
$html = "
<html>
<head>
<title>Form</title>
<link href='style.css' rel='stylesheet'>
</head>
<body>
<div class='login-page'>
  <div class='form'>
<form action='' method='post'>";

for($i=0;$i<count($db);$i++){
	$a[$i] = new Anagrafica($db[$i],$label[$i],$holder[$i],$value[$i],$tipo[$i],$fisso[$i],$visibile[$i]);
	#echo $a->toString();


	$html .= $a[$i]->createHTML();

}

$html .= "<input type='submit'></form></div></div></body></html>";
echo $html;

*/

function createHTML(){
	#non funge nel foreach
}


//converte un xml object in array
function xml2array($xml)
{
    $arr = array();

    foreach ($xml->children() as $r)
    {
        $t = array();
        if(count($r->children()) == 0)
        {
            $arr[$r->getName()] = strval($r);
        }
        else
        {
            $arr[$r->getName()][] = xml2array($r);
        }
    }
    return $arr;
}
?>
