<?php

//includo la classe 
require_once("classe.php");

print_r($_POST);
$a = new Anagrafica();


$a ->setIndirizzo($_POST["indirizzo"]);
$a ->setCognome($_POST["cognome"]);
$a ->setDataNascita($_POST["data_nascita"]);


?>